<?php 
/* 	Innovation Lite Theme's part for showing blog or page in the front page
	Copyright: 2015-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since Innovation Lite 1.0
*/

?>
<div class="clear"></div>
<div id="wpsblogpost" class="box100 bqpcontainer" >
<div id="container" class="f-blog-page">
<?php get_template_part( 'post-content' );  get_sidebar();  ?>
</div>
</div>
