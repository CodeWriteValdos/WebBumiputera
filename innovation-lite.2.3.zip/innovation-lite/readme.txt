----------------------------------
Innovation Lite
----------------------------------
Version: 	2.3
Developer: 	D5 Creation
Author URI: 	https://d5creation.com

Donation Link: 	https://d5creation.com/donate/

Copyright: 	D5 Creation
License: 		GNU General Public License v2 or later
License URI: 	http://www.gnu.org/licenses/gpl-2.0.html

This Product is provided "as is" with no warranty or liabilities of D5 Creation. All the PHP Code, Images and other particulars included with this product are licensed under the same License of the Theme.

Images and Scripts' Licence and Copyright URL
---------------------------------------------------------------------
screenshot.png and
slideback1.jpg		: https://pixabay.com/en/laptop-work-coffee-technology-1209008
slideback2.jpg		: https://pixabay.com/en/office-notes-notepad-entrepreneur-620817
slideback3.jpg		: https://pixabay.com/en/office-tax-business-finance-620822


stf1.jpg	 		: https://pixabay.com/en/woman-portrait-face-model-canon-659352
stf2.jpg 			: https://pixabay.com/en/portrait-photography-girls-woman-828401
stf3.jpg			: https://pixabay.com/en/studio-portrait-woman-face-model-660806

pf1.png			: https://pixabay.com/en/young-woman-girl-lady-female-work-791849
pf2.png			: https://pixabay.com/en/student-typing-keyboard-text-woman-849822
pf3.png			: https://pixabay.com/en/office-tax-business-finance-614213
pf4.png			: https://pixabay.com/en/woman-girl-people-female-hand-792162

FontAwesome		: GPL Friendly Licenses, Source -  http://fortawesome.github.io/Font-Awesome
 jQuery FlexSlider		: License: GPLv2, Copyright: WooThemes,  Author: Tyler Smith, Source: https://github.com/woothemes/FlexSlider
 Modernizr		: License: BSD and MIT, Copyright (c) Faruk Ates, Paul Irish, Alex Sexton, Source: https://modernizr.com

innovation.png - https://pixabay.com/en/woman-model-ipad-happiness-joy-692799
premium.png, newspress.png, simplicity.png - https://pixabay.com/en/model-girl-beauty-bella-fashion-456964


All other images are Lincenced Under GNU GPL and Copyrighted to D5 Creation

Limitations: Site Title/ Logo, Top Menu and Main Menu width is fixed. So you should design those considering these limitations so that they can fit within the container

Instructions:
- You can set the Slider Images, Portfolio,  Heading, Featured Images, Staff Title, Staff Description and Staff Items from Appearance > Innovation Options

Version 2.1
=============================
- Styling Improvement
- Some Image Improvement

Version 2.1
=============================
- Code Cleanup

Version 1.9
=============================
- Mobile Menu Issue Fixed

Version 1.7
=============================
- Code Cleanup
- Link added from Featured Boxes
- Link added from Portfolio
- Facebook, Twitter, YouTuve Social Links added
- Some Images Change

Version 1.05
=============================
- Code Cleanup

Version 1.03
=============================
The 1.03 Version is a Major Version
- Added Customize for Theme Options
- Removed Options Framework
- Code Cleanup





