<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Service five columns', 'insurance-agency' ),
	'description' => esc_html__( 'Add service five columns', 'insurance-agency' ),
	'tab'         => esc_html__( 'Content Elements', 'insurance-agency' ),
);