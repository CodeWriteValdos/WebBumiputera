<?php if (!defined('FW')) die( 'Forbidden' ); ?>
<div class="row circle-service-icon-left">  
<div class="fw-col-lg-12">  
  <div class="img-wrapper"> 
    <div class="img-wrapper-inner"> 
      <img src="<?php echo $atts['imgurl'] ?>" alt=""> 
    </div>
  </div> 
  <div class="text-wrapper"> 
    <h4><?php echo $atts['headline']?></h4>
    <p><?php echo $atts['content']?> </p>
  </div>  
</div>
</div>
