<?php if (!defined('FW')) die( 'Forbidden' ); ?>

<div class="button1 <?php echo $atts['position']?>">
  <a href="<?php echo $atts['url']?>" target="<?php echo $atts['target']?>"><?php echo $atts['content']?></a>
</div>
