<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Service small6', 'insurance-agency' ),
	'description' => esc_html__( 'Always add inside the section - page builder element and add background color or background image to section', 'insurance-agency' ),
	'tab'         => esc_html__( 'Content Elements', 'insurance-agency' ),
);