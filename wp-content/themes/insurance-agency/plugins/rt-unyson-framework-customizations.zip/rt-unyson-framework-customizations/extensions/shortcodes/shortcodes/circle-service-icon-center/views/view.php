<?php if (!defined('FW')) die( 'Forbidden' ); ?>
<div class="fw-col-lg-12 insurance-icons">  
  <div class="insurance-icon"> 
    <img src="<?php echo $atts['imgurl'] ?>" alt=""> 
  </div>
  <h5><?php echo $atts['headline']?></h5>
  <p><?php echo $atts['content']?>
  </p>
</div>
