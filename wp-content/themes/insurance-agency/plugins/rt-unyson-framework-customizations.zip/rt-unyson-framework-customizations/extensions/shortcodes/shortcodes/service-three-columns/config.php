<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Service three columns', 'insurance-agency' ),
	'description' => esc_html__( 'Add service three columns', 'insurance-agency' ),
	'tab'         => esc_html__( 'Content Elements', 'insurance-agency' ),
);