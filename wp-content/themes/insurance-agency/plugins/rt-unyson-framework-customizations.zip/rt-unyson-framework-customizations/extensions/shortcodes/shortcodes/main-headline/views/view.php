<?php if (!defined('FW')) die( 'Forbidden' ); ?>

  <div class="mainheadlinewrapper">
    <div class="<?php echo $atts['textalignment'] ?>">
      <div class="mainheadline">
        <h2><?php echo $atts['headline'] ?></h2>
        <h3><?php echo $atts['subheadline'] ?></h3>
      </div>
    </div>
  </div>

