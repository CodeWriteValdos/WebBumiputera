<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Circle service icon center', 'insurance-agency' ),
	'description' => esc_html__( 'Add circle service icon center', 'insurance-agency' ),
	'tab'         => esc_html__( 'Content Elements', 'insurance-agency' ),
);