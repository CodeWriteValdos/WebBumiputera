<?php if (!defined('FW')) die( 'Forbidden' ); ?>
    <div class="timerwrapper">
      <h3 class="timer" data-to="<?php echo $atts['number']?>" data-speed="100" data-refresh-interval="1">1</h3>
      <h6><?php echo $atts['headline']?></h6>
    </div>