<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Service one column', 'insurance-agency' ),
	'description' => esc_html__( 'Add service one column', 'insurance-agency' ),
	'tab'         => esc_html__( 'Content Elements', 'insurance-agency' ),
);